

<table>
	<tr>
		<td>  <button> <a href="index.php?a=grid&c=Category"> Category  </a>  </button> </td>     
		<td>  <button> <a href="index.php?a=grid&c=Customer"> Customer  </a>  </button> </td>  
		<td>  <button> <a href="index.php?a=grid&c=Product">  Product   </a>  </button> </td>  
		<td>  <button> <a href="index.php?a=grid&c=Admin">    Admin     </a>  </button> </td> 
		<td>  <button> <a href="index.php?a=grid&c=Config">   Config    </a>  </button> </td> 
		<td>  <button> <a href="index.php?a=grid&c=Vendor">   Vendor    </a>  </button> </td> 
		<td>  <button> <a href="index.php?a=grid&c=Salesman"> SalesMan  </a>  </button> </td> 
		<td>  <button> <a href="index.php?a=grid&c=Page">     Page	   </a>   </button> </td> 
	</tr>
	<tr>
		<td> <a href="<?php echo($this->getUrl('logout', 'Admin_Login' , [] , true)); ?>"><h2>LOGOUT</h2></a> </td>
	</tr>
</table>