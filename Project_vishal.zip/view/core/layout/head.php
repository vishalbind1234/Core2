
<head>
	<title> <?php echo($this->getTitle()); ?> </title>
	<style>
		table , tr , td , th 
		{
			border: 2px solid grey ;
			border-collapse: collapse;
		}

		table
		{
			width:100%;
		}

		img
		{
			height: 40px;
			width: 40px;
		}
	</style>
</head>