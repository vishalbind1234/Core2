
<?php Ccc::loadClass('Block_Core_Template'); ?>

<?php



class Block_Salesman_Customer_Product_Grid extends Block_Core_Template{

	protected $customer = null;

	public function __construct()
	{													
		# code...
		$this->setTemplate('view/Salesman/Customer/Product/gridAction.php');					

	}

	public function getSalesmanCustomerProducts()
	{																																
		# code...
		$modelProduct = Ccc::getModel('Product');											
		$productTable = $modelProduct->getResource()->getTableName();
		$row = $modelProduct->fetchAll(" SELECT * FROM {$productTable} ");
		return $row;

	}

/*	public function getSalesmanCustomerProducts()
	{																																
		# code...
		$modelProduct = Ccc::getModel('Product');											
		$productTable = $modelProduct->getResource()->getTableName();
		//$salesmanId = $this->getData('id');
		$row = $modelProduct->fetchAll(" SELECT * FROM {$productTable} ");
		return $row;

	}*/

	public function getCustomer()
	{
		if(!$this->customer)
		{
			$this->setCustomer(Ccc::getModel('Customer'));
		}
		return $this->customer;
	}
	public function setCustomer($customer)
	{
		$this->customer = $customer;
		return $this;
	}


/*	public function getPrice($salesmanId , $customerId , $productId)
	{
				
		$modelProduct = Ccc::getModel('Salesman_Customer_Product');	
		$query = " SELECT * FROM  Salesman_Customer_Price WHERE salesmanId = {$salesmanId} AND customerId = {$customerId} AND productId = {$productId} " ; 				
		$price = $modelProduct->fetchRow($query);
		return $price;

	}*/

	public function getPrice($productId)
	{ 
		$modelCustomer = $this->getCustomer();
		$customer = $modelCustomer->load($this->getData('customerId'));
		$modelSalesmanCustomerProduct = Ccc::getModel('Salesman_Customer_Product');
		return $modelSalesmanCustomerProduct->setCustomer($customer)->getPrice($productId);

	}


}


?>