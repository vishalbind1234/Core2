<?php

Ccc::loadClass('Model_Core_Row');

class Model_Category extends Model_Core_Row {

	protected $category = null;

	const ENABLE = 1;
	const ENABLE_LBL = 'ENABLE';
	const DISABLE = 2;
	const DISABLE_LBL = 'DISABLE';

	public function __construct()
	{
		$this->setResourceName('Category_Resource');
	}

	public function getCategories()
	{
		$categories = $this->fetchAll("SELECT * FROM Category ");
		return $categories;
	}

	public function getStatus()
	{
		$status = [ 
			self::ENABLE => self::ENABLE_LBL ,
			self::DISABLE => self::DISABLE_LBL
		];
		return $status;
	}

	public function getCategoryMedia()
	{
		if(!$this->categoryMedia)
		{
			$this->setCategoryMedia(Ccc::getModel('Category_Media'));
		}
		return $this->categoryMedia;
	}

	public function setCategoryMedia($categoryMedia)
	{
		$this->categoryMedia = $categoryMedia;
		return $this; 
	}




}


?>