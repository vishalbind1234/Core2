
<?php  Ccc::loadClass('Model_Core_Row');  ?>
<?php

class Model_Salesman_Customer_Product extends Model_Core_Row{

	protected $customer = null;

	public function __construct()
	{
		$this->setResourceName('Salesman_Customer_Product_Resource');
		parent::__construct();
	}

	public function getCustomer()
	{
		if(!$this->customer)
		{
			$this->setCustomer(Ccc::getModel('Customer'));
		}
		return $this->customer;
	}
	public function setCustomer($customer)
	{
		$this->customer = $customer;
		return $this;
	}


	public function getPrice($productId)
	{
		return $this->fetchRow("SELECT * FROM Salesman_Customer_Price WHERE salesmanId = {$this->getCustomer()->salesmanId} AND customerId = {$this->getCustomer()->id} AND productId = {$productId} ");
	}

	/*public function getSalesmanCustomerPrice($productId)
	{
		return $this->fetchAll("SELECT * FROM Salesman_Customer_Price WHERE salesmanId = {$this->getCustomer()->salesmanId} AND customerId = {$this->getCustomer()->salesmanId} ");
	}*/


}

?>