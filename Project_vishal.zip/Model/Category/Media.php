<?php Ccc::loadClass('Model_Core_Row'); ?>

<?php

class Model_Category_Media extends Model_Core_Row{

	protected $category = null;

	public function __construct()
	{											
		$this->setResourceName('Category_Media_Resource');
		parent::__construct();
	}

	public function getCategory()
	{
		if(!$this->category)
		{
			$this->setCategory(Ccc::getModel('Category'));
		}
		return $this->category;
	}

	public function setCategory($category)
	{
		$this->category = $category;
		return $this; 
	}

	public function getThum()
	{
		$row = $this->fetchRow("SELECT * FROM Category_Media WHERE categoryId = {$this->getCategory()->id} AND thum = 1");
		return $row;
	}
	
	public function getBase()
	{
		$row = $this->fetchRow("SELECT * FROM Category_Media WHERE categoryId = {$this->getCategory()->id} AND base = 1");
		return $row;
	}
	
	public function getSmall()
	{
		$row = $this->fetchRow("SELECT * FROM Category_Media WHERE categoryId = {$this->getCategory()->id} AND small = 1");
		return $row;
	}

}



?>