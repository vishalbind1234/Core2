<?php

Ccc::loadClass('Model_Core_Row');

class Model_Product extends Model_Core_Row {

	protected $category = null;
	protected $categoryProduct = null;
	protected $productMedia = null;
	protected $salesman = null;
	protected $customer = null;

	const ENABLE = 1;
	const ENABLE_LBL = 'ENABLE';
	const DISABLE = 2;
	const DISABLE_LBL = 'DISABLE';

	public function __construct()
	{
		$this->setResourceName('Product_Resource');					
	}
	
	public function getStatus()
	{
		$status = [ 
			self::ENABLE => self::ENABLE_LBL ,
			self::DISABLE => self::DISABLE_LBL
		];
		return $status;
	}

	public function getCategory()
	{
		if(!$this->category)
		{
			$this->setCategory(Ccc::getModel('Category'));
		}
		return $this->category;
	}

	public function setCategory($category)
	{
		$this->category = $category;
		return $this; 
	}

	public function getCategoryProduct()
	{
		if(!$this->categoryProduct)
		{
			$this->setCategoryProduct(Ccc::getModel('Product_CategoryProduct'));
		}
		return $this->categoryProduct;
	}

	public function setCategoryProduct($categoryProduct)
	{
		$this->categoryProduct = $categoryProduct;
		return $this; 
	}

	public function getProductMedia()
	{
		if(!$this->productMedia)
		{
			$this->setProductMedia(Ccc::getModel('Product_Media'));
		}
		return $this->productMedia;
	}

	public function setProductMedia($productMedia)
	{
		$this->productMedia = $productMedia;
		return $this; 
	}
//--------------------------------------------------------------------------------------------
	public function getSalesman()
	{
		if(!$this->salesman)
		{
			$this->setSalesman(Ccc::getModel('Salesman'));
		}
		return $this->salesman;
	}

	public function setSalesman($salesman)
	{
		$this->salesman = $salesman;
		return $this; 
	}

	public function getCustomer()
	{
		if(!$this->customer)
		{
			$this->setCustomer(Ccc::getModel('Customer'));
		}
		return $this->customer;
	}

	public function setCustomer($customer)
	{
		$this->customer = $customer;
		return $this; 
	}

	/*public function getSalesmanCustomerProducts()
	{
		$this->fetchAll("SELECT * FROM Product WHERE salesmanId in ({$");
	}
*/
}


?>