<?php

Ccc::loadClass('Model_Core_Row');

class Model_Customer extends Model_Core_Row {

	protected $address = null;
	protected $salesman = null;
	protected $product = null;

	const ENABLE = 1;
	const ENABLE_LBL = 'ENABLE';
	const DISABLE = 2;
	const DISABLE_LBL = 'DISABLE';
	
	public function __construct()
	{
		$this->setResourceName('Customer_Resource');
	}

	public function getAddress()
	{
		if(!$this->address)
		{
			$this->setAddress();
		}
		return $this->address;
	}
	public function setAddress()
	{
		$this->address = Ccc::getModel('Customer_Address');         //->fetchRow(" SELECT * FROM Customer_Address WHERE customerId = {$id} ");
		return $this;
	}

	public function getSalesman()
	{
		if(!$this->salesman)
		{
			$this->setSalesman(Ccc::getModel('Salesman'));
		}
		return $this->salesman;
	}
	public function setSalesman($salesman)
	{
		$this->salesman = $salesman ;        
		return $this;
	}

	public function getProduct()
	{
		if(!$this->product)
		{
			$this->setProduct(Ccc::getModel('Product'));
		}
		return $this->product;
	}
	public function setProduct($product)
	{
		$this->product = $product ;        
		return $this;
	}

	public function getSalesmanCustomers()
	{
		$rows = $this->fetchAll("SELECT * FROM Customer WHERE salesmanId in ({$this->getSalesman()->id} , -1)  ");
		return $rows;
	}
	
	public function getStatus()
	{
		$status = [ 
			self::ENABLE => self::ENABLE_LBL ,
			self::DISABLE => self::DISABLE_LBL
		];
		return $status;
	}




}


?>