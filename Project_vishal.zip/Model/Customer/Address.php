<?php  

class Model_Customer_Address extends Model_Core_Row{

	protected $customer = null;

	public function __construct()
	{
		$this->setResourceName('Customer_Address_Resource');

	}

	public function getCustomer()
	{
		if(!$this->customer)
		{
			$this->setCustomer(Ccc::getModel('Customer'));
		}
		return $this->customer;
	}
	public function setCustomer($customer)
	{
		$this->customer = $customer;
		return $this;
	}

	public function getBilling()
	{
		$adapter = $this->getAdapter();
		$query = "SELECT * FROM Customer_Address WHERE customerId = {$adapter->getConnect()->quote($this->getCustomer()->id)} AND billing = 1" ;
		$row = $this->fetchRow($query);
		return $row;
	}

	public function getShipping()
	{
		$adapter = $this->getAdapter();
		$query = "SELECT * FROM Customer_Address WHERE customerId = {$adapter->getConnect()->quote($this->getCustomer()->id)} AND shipping = 1" ;
		$row = $this->fetchRow($query);
		return $row;
	}


}














?>