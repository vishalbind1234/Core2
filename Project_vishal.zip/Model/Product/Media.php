<?php

Ccc::loadClass('Model_Core_Row');

class Model_Product_Media extends Model_Core_Row {

	protected $product = null;

	public function __construct()
	{
		$this->setResourceName('Product_Media_Resource');					
	}

	public function getProduct()
	{
		if(!$this->product)
		{
			$this->setProduct(Ccc::getModel('Product'));
		}
		return $this->product;
	}

	public function setProduct($product)
	{
		$this->product = $product;
		return $this; 
	}

	public function getThum()
	{
		$row = $this->fetchRow("SELECT * FROM Product_Media WHERE productId = {$this->getProduct()->id} AND thum = 1");
		return $row;
	}
	
	public function getBase()
	{
		$row = $this->fetchRow("SELECT * FROM Product_Media WHERE productId = {$this->getProduct()->id} AND base = 1");
		return $row;
	}
	
	public function getSmall()
	{
		$row = $this->fetchRow("SELECT * FROM Product_Media WHERE productId = {$this->getProduct()->id} AND small = 1");
		return $row;
	}




}


?>