<?php

Ccc::loadClass('Model_Core_Row');

class Model_Salesman extends Model_Core_Row {
	
	protected $customer = null;
	//protected $salesmanCustomerProduct = null;

	const ENABLE = 1;
	const ENABLE_LBL = 'ENABLE';
	const DISABLE = 2;
	const DISABLE_LBL = 'DISABLE';

	public function __construct()
	{
		$this->setResourceName('Salesman_Resource');					
	}

	public function getStatus()
	{
		$status = [ 
			self::ENABLE => self::ENABLE_LBL ,
			self::DISABLE => self::DISABLE_LBL
		];
		return $status;
	}


	public function getCustomer()
	{
		if(!$this->customer)
		{
			$this->setCustomer(Ccc::getModel('Customer'));
		}
		return $this->customer;
	}
	public function setCustomer($customer)
	{
		$this->customer = $customer;
		return $this;
	}
	
/*	public function getSalesmanCustomerProduct()
	{
		if(!$this->salesmanCustomerProduct)
		{
			$this->setSalesmanCustomerProduct(Ccc::getModel('Salesman_Customer_Product'));
		}
		return $this->salesmanCustomerProduct;
	}
	public function setSalesmanCustomerProduct($salesmanCustomerProduct)
	{
		$this->salesmanCustomerProduct = $salesmanCustomerProduct;
		return $this;
	}
	*/



}


?>