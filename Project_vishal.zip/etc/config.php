<?php 

return [

	'connection' => [

		"host" => "mysql:localhost"   , 
  		"user" => "vishalbind"        , 
  		"pass" => "vishal"       	  , 
  		"dbname" => "php_practice_db"
	]
];


?>