<?php 

class Model_Product_CategoryProduct extends Model_Core_Row{

	public function __construct()
	{
		$this->setResourceName('Model_Product_CategoryProduct_Resource');
	}


}


 ?>