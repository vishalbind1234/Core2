<?php  

class Model_Customer_Address extends Model_Core_Row{


	public function __construct()
	{
		$this->setResourceName('Customer_Address_Resource');

	}




}














?>